Wind Tunnel CAD - Revision C (2026-10-01)

Open Wind_Tunnel_Assembly.SLDASM with the Parts folder beside it.
SolidWorks 2026 SP2.1 Academic Use Only; that version or newer may be required.
50 native part files: 49 installed types plus a separate measured reference panel.
234 assembly instances, fixed in position. The Drawings folder includes a native
model-linked general arrangement drawing, an 8-sheet labeled PDF and a part key.

This is a nominal reconstruction using build photos, project dimensions and
explicit assumptions. Section sizes: inlet 12 x 12 x 12 in; contraction 12 in;
test passage 6 x 6 x 18 in; diffuser 12 in. Fan nominal 6 in, 8 in envelope.
Plywood radial thickness 0.250 in; acrylic 0.093 in. Base length 64 in assumed.
Caulk fills three assumed 0.125 in section gaps and a 0.125 in test-module offset.
Exact warpage, local gaps and bracket hole geometry were not measured.

Eight 3.5 in corner braces each on contraction and diffuser; eight 2 in on inlet.
Repeated hidden-side hardware and 128 screws represent the modeled fastening
pattern, not a verified purchased inventory. Approximate timber use 19.6 ft before
kerf exceeds the 16 ft early purchase; revise supports or add stock.

Materials are approximate families; zinc steel uses a galvanized steel proxy.
Retain the supplied material database; register its new folder in SolidWorks
material database file locations if editing custom materials after relocation.
No full manufacturing, strength, airtightness, CFD or fastener audit is claimed.
Measurements and missing details are described in Parts_register.csv and the PDF.
