# Wind tunnel — SolidWorks reconstruction

The final delivery contains **50 native part files** (49 used part types plus one measured reference panel) and **234 assembly instances**. The assembly was closed, reopened and checked with zero material, solid-body, feature or reference failures.

Open **Wind_Tunnel_Assembly.SLDASM**. Keep the Parts folder next to the assembly. The parts are native SolidWorks feature models, with separate files for panels and other components. Repeated components use instances of the same part. Assembly components are fixed in position; this is a static layout, not a moving or mate-driven mechanism.

## Design basis

This is a **reconstruction of the documented build with explicit assumed gaps and caulk**, with proposed details where dimensions are missing. It is not a complete metrology model of all hand-cut surfaces. The section sizes retain the documented 12-inch/6-inch nominal interior dimensions, before local caulk fillets. The photographed asymmetric measured panel is supplied separately as `REF_Measured_Trapezoid_A.SLDPRT` and is deliberately not inserted into the nominal assembly.

| Item | Dimension / decision | Basis |
|---|---|---|
| Airflow | Fan pushes into inlet, then contraction, test section, diffuser | August 6 log change and later drawing |
| Test section | 6 × 6 × 18 in nominal clear passage | Project Preparation Steps and drawings |
| Inlet | 12 × 12 in clear passage, 12 in long | Later drawing; 12 × 12 panel cutting log |
| Contraction | 12 to 6 in square, 12 in axial length | Later drawing; 4:1 area ratio |
| Diffuser | 6 to 12 in square, 12 in axial length | Later drawing |
| Fan | 6 in nominal, 8 in axial envelope | VIVOSUN 345 CFM BOM item; later drawing |
| Plywood | 0.25 in BCX | Purchased BOM, preferred over older sketch |
| Acrylic | 0.093 in | Purchased OPTIX sheet specification, preferred over older sketch |
| Honeycomb | 300 × 300 × 15 mm, aramid | BOM and log |
| Frame stock | Nominal 2 × 3 lumber; modeled dressed 1.5 × 2.5 in | Stock type in log; dressed size assumed |
| Weatherstrip | 0.5 × 0.125 in | BOM |
| Magnets | 0.7 in diameter × 0.11 in thick | BOM; eight of nine purchased modeled as four pairs |
| Model rod | 0.25 in diameter stainless steel | Purchased BOM; cut length assumed |
| Inside corner braces | Eight 3.5 in on contraction and eight on diffuser; eight 2 in on inlet | Lengths from package photo 03; inlet/contraction seam placement from photos 13/21; matching diffuser placement added at user request; hidden-side repetition assumed |
| Measured trapezoid A | Wide end 12.00, narrow end 5.75, left edge 12.5, right edge 12.375 in | Handwritten dimensions in 10_IMG_9661.webp |

The inlet spans axial stations 0 to 12 in; the contraction 12.125 to 24.125 in; the test section 24.25 to 42.25 in; and the diffuser 42.375 to 54.375 in. Separate caulk parts fill the three intervening 0.125-inch gaps. The fan spans -8 to 0 in. Overall tunnel length is approximately 62.375 inches; the base rails are 64 inches.

To represent the documented imperfect fit, the acrylic module is offset transversely by **0.125 inch**, and the caulk joints taper across that mismatch and the plywood/acrylic thickness step. **These gap and offset values are assumptions, not recovered measurements of the actual assembly.** The rounded internal plywood corner beads have an assumed 0.125-inch extent; the two acrylic floor seams use 0.0625-inch beads. The removable lid uses weatherstrip.

Dimensions are inch-based and the documents use IPS display units. SolidWorks internally stores meters. Final assembly axes match the installed template: **X airflow, Y transverse, Z vertical**. Individual feature edits do not automatically reposition the fixed assembly components.

## Assumptions and limits

- White caulk is modeled as independent native parts, including corner beads and gap-filling section joints. Its fillets and bulk density are assumed; adhesion, compression and airtightness are not validated. The rod penetration and removable-lid release details still require physical verification.
- Nominal section clearances take precedence where the complete set of as-built mating measurements is unavailable. Photos and the log report approximately ±1/8-inch panel cutting errors and about 1/4-inch assembly discrepancies; these deviations are not silently presented as exact geometry.
- Tapered panels use 0.25-inch radial thickness and square end cuts. Their wall-normal thickness is slightly smaller. These are editable lofts, not manufacturing flat patterns.
- Honeycomb has explicit open hexagonal cells, but its cell size/wall gauge are representative assumptions. The aluminum screens are lightweight open square grids; wire spacing, weave and gauge are not measured. Neither is a CFD porous-medium definition.
- Fan housing, collars and static impeller are simplified representations. Actual blade geometry, motor, electrical wiring, mounting fasteners and internal clearances are not reverse-engineered.
- Support framing, crossbeams, mounting blocks, shelf, magnetic lid tabs and hardware locations are proposed geometry. The fan support and load-cell mounting block are adjusted to meet their supported surfaces, and a sloped saddle supports the diffuser. Verify them against the physical tunnel before fabrication.
- The proposed frame uses approximately 19.6 feet of nominal 2x3 stock before cutting allowance, exceeding the two 8-foot boards in the BOM. Extra stock or a revised support layout is needed; this is not an optimized cut list.
- Photo 21 shows two small braces along each visible inlet corner. Hidden corners repeat that arrangement by assumption, giving eight small braces versus four in the earlier BOM. All modeled holes receive representative screws (128 total versus 24 purchased in the early BOM); these counts describe the CAD layout and are not a verified inventory of the physical build. At user request, the diffuser repeats the contraction arrangement: two 3.5-inch braces per corner seam, starting 1 and 7.875 inches axially from the diffuser inlet. The braces follow its expanding slope.
- The acrylic lid is widened to 7.8 inches for the assumed magnetic tabs. Side walls are shortened by the gasket thickness to retain the nominal 6-inch central clear height. Gasket contact, compression and the end seal details are not production-validated.
- The clear vinyl U-tube is a schematic hollow part with assumed 1/4-inch OD, 1/8-inch ID, 1-inch bend radius and 5-inch legs; pressure connections and fluid are omitted.
- Electronics and load cell are envelope models. Connector placement, load-cell flexures, wiring and calibration are omitted. The 8-mm rod hole and its axial location are assumptions.
- Braces are long folded strips along the seams, with holes through both flanges. The 3.5-inch version represents an installed bend opened to 93.37 degrees to fit the nominal tapered corner; actual forming was not measured. Flange width (0.75 inch), gauge (0.075 inch) and hole diameter (0.21 inch) are assumptions. Screws use smooth shafts and simple heads; threads, countersinks and wood pilot drilling are omitted. A full assembly interference, fastening and tolerance audit has not been performed.
- Custom material labels and appearance match intended material families. Densities in the supplied material database are explicit approximations. Zinc-plated hardware uses a galvanized-steel library proxy. The models are not certified structural, mass, fan-performance or aerodynamic analyses.
- The current local engineering log through August 29 was recovered with shared read access and reviewed, together with both reference drawings, the BOM, available project chat, and the 21 local portfolio build photos. The August 29 entry reports a connected, airtight inlet/contraction and a warped acrylic section; no warp measurements are supplied, so the acrylic panels are modeled flat. Additional unavailable project history has not been claimed as reviewed.

## Engineering drawings and portfolio

Revision D contains a 51-sheet PDF: one labeled assembly overview and P01-P50 individual part sheets. Each part sheet includes a SolidWorks isometric view, three orthographic views, overall dimensions, and feature dimensions/details. `Drawings/Parts/` contains all 50 native model-linked SLDDRW files. `Part_Drawing_Dimensions.csv` maps part IDs, PDF pages, quantities, materials, and detailed dimensions. The general-arrangement SLDDRW is also retained.

Views are linked to the models; dimension lines, values, and detail notes are drafting annotations captured from the current geometry, not associative SolidWorks driving dimensions. Regenerate or verify annotations after changing a part. Views are independently scaled and explicitly labeled. Tapered panels are lofted solids, not manufacturing flat patterns. Purchased-component internals, unmodeled holes/threads, and unmeasured fit details are not fabricated measurements.

The acrylic floor now has its 8 mm rod-clearance through-hole at X=9 in, Y=0 in local part coordinates. The downloadable model and P09 sheet agree.

The portfolio at https://elijah-dickinson-portfolio-elijahdickinson-6988.vercel.app/#wind-drawings provides a searchable selector for all 51 sheets, enlarged views, direct PDF page links, and PDF/CAD downloads. The public CAD ZIP excludes original source records and reference photos; this local delivery retains them.

## Files

- `Wind_Tunnel_Assembly.SLDASM`: final static native assembly.
- `Parts/`: native individual parts, including a separate measured reference panel.
- `Parts_register.csv`: quantities, assigned material names and dimensional basis.
- `Wind_Tunnel_Materials.sldmat`: custom nominal material definitions; retain beside the assembly. It is registered on this computer; after moving the project elsewhere, add its new folder under SolidWorks material database file locations if needed for editing custom materials.
- `Reference/`: selected original reference photos and drawings. The early sketch in 01_IMG_9617 is superseded on fan direction and purchased sheet thicknesses by later records.
- `Verification/`: verification records. The initial `Final_validation.txt` records material-registration errors that were subsequently resolved; `Material_verification.txt` confirms all 50 materials. `Hardware_verification.txt` covers the initial corrected braces, `Diffuser_verification.txt` covers the eight added diffuser braces and their 48 screws, and `Delivery_verification.txt` records the preceding full part check. `Diffuser_reopen_verification.txt` verifies the final 234-instance assembly after the diffuser update.
- `Assembly_preview.png` and `Corner_brace_detail.png`: images exported from the native model.

Generated with SolidWorks 2026 SP2.1, Academic Use Only. Files may require that version or newer to open natively.

SolidWorks API reference used for the hollow U-bend: [FeatureRevolve2 documentation](https://help.solidworks.com/2021/English/api/sldworksapi/SOLIDWORKS.Interop.sldworks~SOLIDWORKS.Interop.sldworks.IFeatureManager~FeatureRevolve2.html).
